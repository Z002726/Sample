﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Call FillData()

        cb1.Text = 0
        cb2.Text = 0
        cb3.Text = 0
        cb4.Text = 0
        cb5.Text = 0
        cb6.Text = 0

    End Sub

    Private Sub FillData()

        For i = 0 To 100

            cb1.Items.Add(i)
            cb2.Items.Add(i)
            cb3.Items.Add(i)
            cb4.Items.Add(i)
            cb5.Items.Add(i)
            cb6.Items.Add(i)

        Next
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click

        If txtName.Text = "" Or Len(txtName.Text) = 0 Then
            MsgBox("Please enter the Employee Name", MsgBoxStyle.Information, "Warning!")
            txtName.Focus()
            Exit Sub
        End If

        Dim intTotal As Double

        intTotal = Val(cb1.Text) + Val(cb2.Text) + Val(cb3.Text) + Val(cb4.Text) + Val(cb5.Text) + Val(cb6.Text)

        intTotal = (intTotal / 6)

        lblPercentage.Text = Format(intTotal / 100, "0%")

        lblName.Text = txtName.Text

    End Sub
End Class
